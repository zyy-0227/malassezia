rm(list=ls())
if (!requireNamespace("devtools", quietly = TRUE)) {
  install.packages("devtools")
}
devtools::install_version("randomForestSRC", version = "3.3.0")
library(Mime1)
setwd("C:\\Users\\20396\\Desktop\\组会\\BLCA\\运行数据\\独立验证集")
genelist<-read.csv("common.csv")
genelist<-genelist$x
tcga <- read.table("tcga.txt", header = T, sep = "\t", quote = "", check.names = F)
GSE32548 <- read.table("GSE32548.txt", header = T, sep = "\t", quote = "", check.names = F)
#GSE48276 <- read.table("GSE48276.txt", header = T, sep = "\t", quote = "", check.names = F)
colnames(tcga)[1]<-"ID"
colnames(GSE32548)[1]<-"ID"
#colnames(GSE48276)[1]<-"ID"
# 生成包含三个数据集的列表
mm <- list(TCGA = tcga,
           GSE32548=GSE32548#,GSE48276=GSE48276
           )
#对mm中每个元素的第4列及以后的数据进行标准化（中心化和缩放）
# mm <- lapply(mm,function(x){
#   x[,-c(1:3)] <- scale(x[,-c(1:3)])
#   return(x)})
library(snowfall)
# 初始化并行计算环境
sfInit(parallel = TRUE, cpus = 4)
##修改原码trace(ML.Dev.Prog.Sig,edit=T)
res <- ML.Dev.Prog.Sig(train_data = mm$TCGA,
                       list_train_vali_Data = mm,
                       unicox.filter.for.candi =T,
                       unicox_p_cutoff = 0.05,
                       candidate_genes = genelist,
                       mode = 'all',nodesize =8,seed = 123456)
p<-cindex_dis_all(res,
               validate_set = names(mm)[-1],
               order = names(mm),
               width = 0.3)
ggsave("C:\\Users\\20396\\Desktop\\组会\\BLCA\\运行数据\\独立验证集\\最终.pdf", plot = p, width = 10, height = 15, units = "in")
#导出
write.csv(res["Cindex.res"], file="cindex_res.csv", quote=FALSE)
write.csv(res["Sig.genes"], file="unicox.csv",quote=F)

#风险评分
a<-res$riskscore$`StepCox[forward] + RSF`[[1]]
write.csv(a,"tcgariskscore.csv", row.names = TRUE)
b<-res$riskscore$`StepCox[forward] + RSF`[[2]]
write.csv(b,"gseriskscore.csv", row.names = TRUE)
##C指数
cindex_dis_select(res,
                  model="StepCox[forward] + RSF",
                  order= names(mm))
##K-M曲线
survplot <- vector("list",2)
for (i in c(1:2)) {
  print(survplot[[i]]<-rs_sur(res, model_name = "RSF",
                              dataset = names(mm)[i],
                              #color=c("blue","green"),
                              median.line = "none",
                              cutoff = 0.5,
                              conf.int = T,
                              xlab="Day",
                              #pval.coord=c(1000,0.9)
                              )
        
        )
  }
aplot::plot_list(gglist=survplot,ncol=2)
###随机森林画图
c<-res$ml.res$`RSF`
plot(c)


