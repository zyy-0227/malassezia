rm(list=ls())
#相关R包载入：
library(ggplot2)
library(pheatmap)
library(ggplotify)
library(cowplot)
# rnadata<-read.csv("C:/Users/20396/Desktop/组会/BLCA/基础数据/整理得到的数据/BLCA_rnadata_93.csv",row.names=1)
# gene<-c("CLSTN3","ADCY7","CD109","OSBPL7","GPRIN1","RNF217","TRAPPC6A","TMEM25","TEKT5","CAPS",
#          "MYCN","LYPD6","SNCG")
# rnadata<-rnadata[,colnames(rnadata) %in% gene]
# write.csv(rnadata,"C:\\Users\\20396\\Desktop\\组会\\BLCA\\运行数据\\风险因子联动图\\tcgagene.csv")
data<-read.csv("C:\\Users\\20396\\Desktop\\组会\\BLCA\\运行数据\\风险因子联动图\\tcga.csv",check.names = FALSE,row.names=1)
data<- data[order(data$Riskscore,decreasing = F),] #按风险评分从低到高排序
data$id <- c(1:length(data$Riskscore)) #根据调整后顺序建立编号id
#1.1.风险评分散点图绘制：
p1<- ggplot(data,aes(x = id,y = Riskscore)) +
  geom_point(aes(col = group)) +
  scale_colour_manual(values = c("blue","red")) +
  geom_hline(yintercept = median(data$Riskscore), colour="grey", linetype="dashed", size=0.8) +
  geom_vline(xintercept = sum(data$group == "low"), colour="grey", linetype = "dashed", size = 0.8) +
  theme_bw()
p1
data$OS <- factor(data$OS,levels = c("1","0")) #指定因子调整顺序
#1.2.患者生存时间散点图绘制：
p2<- ggplot(data,aes(x = id,y = OS.time)) +
  geom_point(aes(col = OS)) +
  scale_colour_manual(values = c("red","blue")) +
  geom_vline(xintercept = sum(data$group == "low"), colour = "grey", linetype = "dashed", size = 0.8) +
  theme_bw()
p2

#1.3.表达量热图绘制：
exp<- data[,c(5:31)] #提取表达矩阵,并调整一下顺序(按风险因子和保护因子排列)
head(exp)
annotation<-data.frame(cbind(rownames(data),data[,4]))
colnames(annotation)<-c("id","Type")
annotation<- annotation[order(annotation$Type,decreasing = F),]
rownames(annotation)<-annotation$id
annotation$Type<- as.factor(annotation$Type)
mycol<- colorRampPalette(c("blue","yellow","red"))(100) #自定义颜色
exp2<- t(scale(exp)) #矩阵标准化：
exp2[1:5,1:4]
# 对annotation按Type列进行排序，并获取排序后的id
sorted_ids <- annotation[order(annotation$Type, decreasing = FALSE), "id"]

# 根据sorted_ids重新排列exp的列
exp2<- exp2[, match(sorted_ids, colnames(exp2))]
##将exp的列按照annotation的id排序

ann_colors<- list(Type = c('low' = "blue",
                            'high' = "red")) #添加分组颜色信息
#绘图：
p3<-pheatmap(exp2,
         col= mycol,
         cluster_rows= F,
         cluster_cols= F,
         show_colnames= F,
         annotation_col= annotation,
         annotation_colors= ann_colors,
         annotation_legend= F
)
p3
#拼图实现三图联动
library(patchwork)
p1/p2/as.ggplot(p3)
library(tinyarray)
n = scale(t(exp2))
p3 = ggheat(n,
            data$group,
            show_rownames = F)+
  theme(axis.text = element_text(size = 8))
p3
p1 /p2 /p3 + plot_layout(design = 'A
                         B
                         C
                         C
                         C
                         C')