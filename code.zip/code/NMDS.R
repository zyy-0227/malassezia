############清理环境############
rm(list=ls())
##########加载必要的包##############
library(ggplot2)
library(ggrepel) 
# 用于更好地显示文本标签，防止标签重叠
library(ggthemes) 
# 提供更多主题
library(viridis) 
# 连续或离散调色板
library(ggforce) 
# 有一些特殊几何体函数，比如 geom_mark_ellipse
library(tidyverse)
library(vegan)
###############读取OTU表和分组表#################
data1<-read.csv("C:/Users/20396/Desktop/组会/BLCA/基础数据/整理得到的数据/BLCA_countdata_290.csv",check.names = FALSE)
rownames(data1)<-data1[,1]
data1<-data1[,-1]
data1<-data.frame(t(data1),check.names = FALSE)
# fungi<-read.csv("C:/Users/20396/Desktop/组会/BLCA/基础数据/整理得到的数据/真菌.csv",check.names = FALSE)
# data1<-data1[rownames(data1) %in% fungi$sampleid,]
group<-read.csv("C:/Users/20396/Desktop/组会/BLCA/基础数据/整理得到的数据/BLCA_mergedata_290.csv")
group<-group[,c(1,293)]##meta
# ###############对样本进行抽平#################
set.seed(123456)
bac_asv_rari <-as.data.frame(t(rrarefy(t(data1),min(colSums(data1))))) %>% # 先计算每一列（即每个样本）的序列总和，并找出最小的总和。rrarefy() 函数对 “转置后” 的矩阵进行稀有化处理，使得每个样本（现在是每一行）的序列计数等于最小的样本序列总和，然后再转回原来的行列关系。
  filter(.,rowSums(.)>0)# 筛选出每个asv（相当于行的总数）大于0的
colSums(bac_asv_rari)
bac_asv_rari
###################计算距离矩阵###################
#> 计算bray_curtis距离：NMDS分析或PCoA分析
bac_distance <- bac_asv_rari %>%
  t() %>%
  vegan::vegdist(method = 'bray')  # 使用vegan::明确指定函数来源# Bray-Curtis 距离是一genus度量两个样本在物genus组成上差异的方法

bac_data <- bac_asv_rari %>%
  t() %>%
  as.data.frame() %>%
  rownames_to_column(var='sampleid') %>%
  left_join(.,group,by='sampleid')

# 置换多元方差分析（PERMANOVA）：不符合正态分布
PERMANOVA_bac <- adonis2(bac_distance ~ group ,
                         data = bac_data , permutations =999)
PERMANOVA_bac

#######NMDS用于可视化样本间的相似性或差异性，但它本身无法判断差异是否显著。
###> NMDS分析:应力值小于0.2被认为是一个很好的拟合
set.seed(156)
# #NMDS排序，定义2个维度，详情?metaMDS
bac_NMDS <- metaMDS(bac_distance, k =2)
# 应力函数值，一般不大于 0.2 为合理
bac_NMDS$stress
bac_NMDS_points <-as.data.frame(bac_NMDS$points) %>%
  rownames_to_column(var='sampleid') %>%
  left_join(.,group,by='sampleid')

########################绘图模板3##########################
bac_NMDS_p2 <- ggplot(bac_NMDS_points, aes(x = MDS1, y = MDS2, color = group)) +
  geom_point(size = 4, alpha = 0.8) +
  # 椭圆包络
  stat_ellipse(aes(fill = group),
  geom = "polygon",
  alpha = 0.2,
  show.legend = FALSE) +
  # # 在图中加上 stress 值
  # annotate("text",
  #          x = 1,
  #          y = 2,
  #          label = paste0("Stress = ", round(bac_NMDS$stress, 3)),
  #          size = 5) +
  # 手动设置颜色和填充，也可用 scale_color_manual
  scale_color_viridis(discrete = TRUE, option = "D") +
  scale_fill_viridis(discrete = TRUE, option = "D") +
  theme_bw() +
  theme(
    panel.grid.major = element_line(color = "grey85"), 
    panel.grid.minor = element_blank(),
    legend.position = "right",
    axis.title.y = element_text(size = 26,color="black"),
    axis.title.x = element_text(size = 26,color="black"),
    legend.title = element_blank()  ) +
  labs(x = "NMDS1",
       y = "NMDS2")
bac_NMDS_p2
#ggsave(plot = bac_NMDS_p2,filename = "NMDS2.pdf",dpi = 300,width = 8,height = 6)


############################模板4######################
####### 计算各组的中心（这里用平均值）
centroids <- bac_NMDS_points %>%  group_by(group) %>%
  summarise(MDS1 = mean(MDS1), MDS2 = mean(MDS2))
bac_NMDS_p3  <- ggplot(bac_NMDS_points, aes(x = MDS1, y = MDS2, color = group)) +
  # 绘制星形连接线：每个点 -> 对应分组的中心
  geom_segment(
    data = bac_NMDS_points %>% left_join(centroids, by="group", suffix = c("", "_centroid")),
    aes(xend = MDS1_centroid, yend = MDS2_centroid),
    alpha = 0.4  ) +
  geom_point(size =2) +
  # 绘制分组中心点
  geom_point(data = centroids,
             aes(x = MDS1, y = MDS2, color = group),
             size = 2.5, shape = 8, stroke = 2,show.legend = F) +
  #标注 stress
  annotate("text",
  x = 0.8,
  y = 0.9,
  label = paste0("Stress = ", round(bac_NMDS$stress, 3)),
  size = 5, color = "black") +
  # 椭圆包络
  stat_ellipse(aes(fill = group),
               geom = "polygon",
               alpha = 0.2,
               fill=NA,
               show.legend = FALSE,
               linetype = "solid",  # 边框线型
               linewidth = 0.75) +
  scale_color_manual(values = c("#ed3e2e","#00aae3","#018A67","#F3A332"))+
  # ggdark::dark_theme_bw(base_size = 14) +   # 来自 ggdark
  theme_bw()+
  theme(
    legend.position = "right",
    legend.title = element_blank(),
    axis.text = element_text(size = 30,color="black"),
    axis.title = element_text(size = 30,color="black"),
    legend.text = element_text(size = 20),
    plot.title = element_text(size = 30)  ) +
  labs(x = "NMDS1",
       y = "NMDS2")
bac_NMDS_p3
#ggsave(plot = bac_NMDS_p3,filename = "NMDS3.pdf",dpi = 300,width = 10,height = 8)